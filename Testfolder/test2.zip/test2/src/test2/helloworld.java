package test2;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.PrintWriter;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;




public class helloworld {

	 
	    public static void main(String[] args) {
	    	
	    	getPage();
	        
	        // exit the program explicitly
	        System.exit(0);
	    }
	    
	    private static void getPage() {

	    	try {
		        // declaration and instantiation of objects/variables
		        WebDriver driver = new FirefoxDriver();
		        Robot robot = new Robot();
		        String baseUrl = "https://pbanssb.ucmerced.edu/pls/PROD/xhwschedule.p_selectsubject";
		 
		        // launch Firefox and direct it to the Base URL
		        driver.get(baseUrl);
		 
		        // input value (semester) will be given by the user
		        driver.findElement(By.cssSelector("input[value='201610']")).click();
		        driver.findElement(By.name("validterm")).submit();
		        
		        String htmlsource = driver.getPageSource(); 
		        try(  PrintWriter out = new PrintWriter( "testsource2.html" )  ){
		            out.println( htmlsource );
		        }
		        
		        driver.close();
	    	}
	    	catch(Exception e) {
	    		
	    	}
		}
	 
}
